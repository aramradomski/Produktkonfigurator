# UPS Live-Preise — Setup-Anleitung

**Stand:** April 2026 · UPS API v2403 · OAuth 2.0 (Client Credentials)

## Was ist neu

Der Konfigurator kann jetzt **Live-Preise von UPS** abrufen — nicht mehr nur die hardcoded Tarif-Tabelle. Das löst exakt das Problem aus dem Druckerei-Feedback ("bei Fracht haben wir fast Tagespreise").

### Architektur

```
Browser (tapete.html)
    │
    │  POST { weightKg, lengthCm, ..., destPostalCode }
    ▼
Netlify Function (ups-rate.js)
    │
    │  OAuth 2.0 — Bearer Token cached
    ▼
UPS Rating API (onlinetools.ups.com)
    │
    │  Antwort: alle Services + Berlintapete-Vertragspreise
    ▼
Browser
```

**Warum Server-Proxy?**
- UPS-Credentials dürfen nie im Browser stehen (sonst geklaut)
- OAuth-Token-Caching geht nur serverseitig
- CORS würde direkten Browser→UPS sowieso blockieren

---

## Schritt 1: UPS Developer Account

1. Gehe zu **https://developer.ups.com**
2. Logge dich mit deinem Berlintapete-UPS-Account ein (gleicher Login wie das Versand-Portal)
3. Klick **"Apps" → "Add Apps"**
4. Wähle:
   - **"I want to integrate UPS technology into my business"**
   - Account: deine Berlintapete-Kundennummer
5. App-Name: `Berlintapete-Konfigurator`
6. Wähle die nötigen APIs:
   - ✅ **Authorization (OAuth)**
   - ✅ **Rating** (das brauchen wir für Preise)
   - ⏸ Shipping (später für Label-Generation)
   - ⏸ Tracking (später für Sendungsverfolgung)
7. Submit → du bekommst **Client ID** und **Client Secret**

**Wichtig:** Client Secret kann nur **einmal** angezeigt werden — sofort sicher speichern (z.B. in 1Password).

---

## Schritt 2: Netlify-Setup

### Environment-Variablen setzen

Im Netlify-Dashboard:
**Site Settings → Environment Variables → Add a variable**

```
UPS_CLIENT_ID         = [aus Schritt 1]
UPS_CLIENT_SECRET     = [aus Schritt 1]
UPS_ACCOUNT_NUMBER    = [Berlintapete UPS-Kundennr — wichtig für Vertragspreise!]
UPS_ENV               = test
SHIPPER_NAME          = Berlintapete GmbH
SHIPPER_POSTAL_CODE   = 10115
SHIPPER_COUNTRY       = DE
UPS_DEBUG             = true
```

### Test-Modus zuerst!
- `UPS_ENV=test` nutzt die UPS Customer Integration Environment (CIE) → keine echten Kosten
- `UPS_ENV=production` schaltet auf Live-Preise um

### Deploy
Nach Variablen-Set: **Deploys → Trigger deploy → Clear cache and deploy site**

---

## Schritt 3: Test

### Console-Test im Browser
Öffne den Konfigurator → DevTools-Konsole (`F12`) → einfügen:

```javascript
// Test mit Berlin → München
fetch('/.netlify/functions/ups-rate', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    weightKg: 5,
    lengthCm: 280, widthCm: 18, heightCm: 18,
    destPostalCode: '80331',
    destCountry: 'DE'
  })
}).then(r => r.json()).then(console.log)
```

**Erwartete Antwort:**
```json
{
  "ok": true,
  "env": "test",
  "rates": [
    { "serviceCode": "11", "serviceLabel": "UPS Standard", 
      "amount": 18.45, "currency": "EUR", "isNegotiated": true },
    { "serviceCode": "65", "serviceLabel": "UPS Worldwide Saver",
      "amount": 32.12, "currency": "EUR" }
  ]
}
```

### UI-Test
Im Konfigurator nach Bild-Upload + Maß-Wahl:
```javascript
window.refreshShippingPriceLive()
```

Wenn alles klappt: `● UPS Live: 18.45 EUR — UPS Standard (Δ +1.20 € vs Schätzung)`

---

## Schritt 4: UI im Konfigurator anbinden

Aktuell ruft der Konfigurator noch die statische `calcShipping()` für die Preisberechnung auf. Die Live-Berechnung muss noch in den **Checkout-Flow** integriert werden:

### Option A — Beide Anzeigen
Statisch (sofort) + Live-Update wenn der Kunde die PLZ eingibt.

### Option B — Nur Live (empfohlen für B2B)
Beim Cart-Checkout zwingt der Konfigurator zur PLZ-Eingabe und zeigt nur dann einen Preis.

**Empfohlene Position im UI:** Im Cart-Sheet, unter den Items, vor dem "Bestellen"-Button.

---

## Schritt 5: Production-Hardening

Bevor du auf Live umstellst:

### 5.1 CORS einschränken
In `ups-rate.js` Zeile 20:
```javascript
'Access-Control-Allow-Origin': 'https://www.berlintapete.de'
```
Mehrere Domains? Whitelisting per Header-Check.

### 5.2 Rate-Limiting
Der Proxy hat kein Limit — schütze ihn vor Bot-Spam:
- Netlify-eigenes [Edge Rate-Limiting](https://docs.netlify.com/edge-functions/api/#rate-limiting)
- Oder: Cloudflare davor

### 5.3 Error-Logging
Logging via Netlify-Logs:
```javascript
console.log('[UPS]', {input, response, latencyMs})
```
Auch besser: Sentry oder Logtail.

### 5.4 Token-Refresh-Monitoring
Der Token cached 4h. Bei Spitzenlast **kann** UPS den Token vorzeitig invalidieren. Deshalb:
- Bei 401 Fehler: Token wegwerfen + neu holen + Request wiederholen
- Diese Retry-Logik ist im aktuellen Code noch **nicht** drin (kann ich ergänzen wenn du willst)

---

## UPS-Service-Codes (Übersicht)

Wichtigste Services für Berlintapete (DE-Inland):

| Code | Service | Standard-Laufzeit |
|---|---|---|
| `11` | UPS Standard | 1–2 Tage |
| `65` | UPS Worldwide Saver | 1 Tag |
| `07` | UPS Worldwide Express | 1 Tag |
| `54` | UPS Worldwide Express Plus | vor 9 Uhr |
| `74` | UPS Express 12:00 | vor 12 Uhr |
| `82` | UPS Today Standard | Same-day |

Im Konfigurator empfehle ich **`11` (Standard)** als Default + Express als Aufpreis-Option.

---

## Was du vermutlich als nächstes brauchst

1. **DHL anbinden** — gleiches Pattern, andere API
2. **Label-Generation** — wenn der Kunde bestellt, Label-PDF holen
3. **Tracking-Webhooks** — Sendungsstatus an Kunden mailen
4. **Dynamic Tarif-Update** — die Druckerei klagt über Tagespreise, das ist jetzt gelöst

---

## Probleme / FAQ

**„invalid_grant" beim Token-Holen?**
→ Client ID oder Secret falsch. Im Netlify-Dashboard prüfen.

**„Account number not associated with login"?**
→ `UPS_ACCOUNT_NUMBER` muss zur App-Registrierung passen.

**Public Rates statt eigene Vertragspreise?**
→ `UPS_ACCOUNT_NUMBER` setzen + im Netlify deployt sein. Bei `negotiated rates`: bei UPS-Account-Manager freischalten lassen.

**Netlify-Function timed out?**
→ UPS antwortet manchmal langsam (>10s). Erhöhe Function-Timeout im `netlify.toml`:
```toml
[functions]
  timeout = 26
```

**CORS-Fehler im Browser?**
→ `Access-Control-Allow-Origin` in `ups-rate.js` muss zur aufrufenden Domain passen.

---

## Datei-Lokationen

- **Proxy:** `netlify/functions/ups-rate.js`
- **Konfigurator-Logik:** `tapete.html` (Funktion `calcShippingLive`)
- **Diese Anleitung:** `UPS-Setup-Anleitung.md`

## Kontakt für Implementierung

Daniel von der Druckerei ist gemäß deinem Hinweis der richtige Ansprechpartner für die wallcreator-Schnittstelle. Für UPS-Setup braucht er nichts — das läuft vollständig auf der Berlintapete-Seite.
