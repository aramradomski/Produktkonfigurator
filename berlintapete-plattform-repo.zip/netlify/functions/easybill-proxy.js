// ════════════════════════════════════════════════════════════════
// Easybill API Proxy — Netlify Function
// Hält den API-Key serverseitig, niemals im Browser sichtbar.
// Route: /easybill/* → /.netlify/functions/easybill-proxy/*
//        (siehe _redirects)
//
// Setup:
//   Netlify Dashboard → Site settings → Environment variables
//   Add Variable: EASYBILL_API_KEY = <dein-api-key-aus-easybill>
//
// Easybill API-Key generieren:
//   easybill.de → Einstellungen → API → Neuen API-Schlüssel anlegen
//   Berechtigung: Lesen + Schreiben für Kunden + Dokumente
// ════════════════════════════════════════════════════════════════

const ALLOWED_METHODS = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'];
const EASYBILL_BASE   = 'https://api.easybill.de/rest/v1';

function corsHeaders(origin) {
  return {
    'Access-Control-Allow-Origin':  origin || '*',
    'Access-Control-Allow-Methods': ALLOWED_METHODS.join(', '),
    'Access-Control-Allow-Headers': 'Content-Type, Accept',
    'Access-Control-Max-Age':       '600',
  };
}

function jsonResponse(status, body, origin) {
  return {
    statusCode: status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders(origin) },
    body: typeof body === 'string' ? body : JSON.stringify(body),
  };
}

exports.handler = async (event) => {
  const origin = event.headers?.origin || event.headers?.Origin || '*';

  // CORS Preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: corsHeaders(origin), body: '' };
  }

  // Methoden-Whitelist
  if (!ALLOWED_METHODS.includes(event.httpMethod)) {
    return jsonResponse(405, { error: 'Method not allowed' }, origin);
  }

  // API-Key prüfen
  const apiKey = process.env.EASYBILL_API_KEY;
  if (!apiKey) {
    return jsonResponse(503, {
      error: 'Easybill not configured',
      hint:  'Set EASYBILL_API_KEY in Netlify Environment Variables (Site settings → Environment variables)',
    }, origin);
  }

  // Subpath nach /easybill/ oder /.netlify/functions/easybill-proxy/ extrahieren
  let subpath = event.path || '';
  subpath = subpath.replace(/^\/\.netlify\/functions\/easybill-proxy/, '');
  subpath = subpath.replace(/^\/easybill/, '');
  if (subpath && !subpath.startsWith('/')) subpath = '/' + subpath;

  // Query String erhalten
  const queryParams = event.rawQuery
    || (event.queryStringParameters
         ? new URLSearchParams(event.queryStringParameters).toString()
         : '');
  const queryString = queryParams ? '?' + queryParams : '';

  const upstreamUrl = `${EASYBILL_BASE}${subpath}${queryString}`;

  // Headers für Easybill aufbauen — Bearer kommt nur hier rein, nirgends im Client
  const upstreamHeaders = {
    'Authorization': `Bearer ${apiKey}`,
    'Accept':        'application/json',
    'User-Agent':    'Berlintapete-Konfigurator/1.0',
  };
  if (event.body && event.httpMethod !== 'GET' && event.httpMethod !== 'HEAD') {
    upstreamHeaders['Content-Type'] = 'application/json';
  }

  try {
    const res = await fetch(upstreamUrl, {
      method:  event.httpMethod,
      headers: upstreamHeaders,
      body:    (event.httpMethod === 'GET' || event.httpMethod === 'HEAD') ? undefined : event.body,
    });

    const responseText = await res.text();

    // Loggen ohne sensible Daten (für Netlify Function Logs)
    console.log(`[EB-Proxy] ${event.httpMethod} ${subpath} → ${res.status}`);

    return {
      statusCode: res.status,
      headers: {
        'Content-Type': res.headers.get('content-type') || 'application/json',
        ...corsHeaders(origin),
      },
      body: responseText,
    };
  } catch (err) {
    console.error('[EB-Proxy] Network error:', err.message);
    return jsonResponse(502, {
      error:   'Easybill upstream error',
      message: err.message,
    }, origin);
  }
};
