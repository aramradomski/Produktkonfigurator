# ARAM RADOMSKI · BIOGRAFIE & WERKAKTE

**Stand:** 28. April 2026
**Quellen:** Wikipedia · Bundesstiftung Aufarbeitung · jugendopposition.de · Robert-Havemann-Gesellschaft · Zeitzeugenbüro · WiWo · Deutsche Gesellschaft e.V. · Bundeszentrale für politische Bildung · Eigenes Werkverzeichnis

---

## 1 · STAMMDATEN

| Feld | Wert |
|---|---|
| **Geburtsname** | Aram Neumann (bis 1983) |
| **Heutiger Name** | Aram Radomski (seit Personalausweis-Wiederausstellung 1983) |
| **Geboren** | 19. Februar 1963 in Neubrandenburg, DDR |
| **Aktueller Wohnort** | Berlin |
| **Beruf** | Fotograf, Designer, Unternehmer, Zeitzeuge |
| **Aktuelle Position** | Geschäftsführer Berlintapete GmbH (seit 2002) |

---

## 2 · HERKUNFT & FAMILIE

### Mütterliche Linie
- **Margarete Neumann** (Großmutter): Linientreue, SED-nahe Schriftstellerin aus Ostpreußen — war anerkannt im DDR-Kulturbetrieb

### Väterliche Linie
- **Gert Neumann** (Vater): Schriftsteller, regimekritisch
  - 1967: Wechsel nach Leipzig zum Studium am Institut für Literatur **„Johannes R. Becher"**
  - Stand spätestens ab Mitte/Ende 1970er unter massiver Stasi-Observierung
  - Wurde 1979 vom MfS aktiv „bearbeitet" zur Ausreise zu nötigen
  - Versuchte Buchveröffentlichung in der Bundesrepublik 1979

### Kindheit
- Aufgewachsen in **Groß Nemerow am Tollensesee** (Mecklenburg)
- Eltern heirateten als Aram drei Monate alt war → Familienname „Neumann"
- Schriftstellerhaushalt — frühe Konfrontation mit politischer Bewachung der Familie

---

## 3 · DDR-BIOGRAFIE 1979-1989

### 1977 (14 Jahre)
Lebt ein Jahr beim Vater in Leipzig — direkter Kontakt mit Stasi-überwachtem Schriftsteller-Milieu

### 1979 (16 Jahre)
**Erster Stasi-Anwerbungsversuch.** Aram wird gefragt, ob er seinen Vater bespitzeln will. **Lehnt ab.** Damit beginnt die eigene Bearbeitung durch das MfS.

### 1979-1983 — Plauen
- Ausbildung zum **Agrotechniker** in Neubrandenburg
- Hilfsarbeiter im Krankenhaus von Neubrandenburg
- Umzug nach **Plauen** (Sachsen) — Arbeit als Handwerker an der dortigen Fachhochschule
- Beziehung mit einer **mongolischen Gaststudentin** (Studentin der Naturwissenschaften)

### Februar 1983 — Verhaftung in Plauen
- Faschingsfeier in einem Jugendclub
- Wird zusammengeschlagen — von Stasi-Mitarbeitern, was er nicht weiß
- Wird **als Täter verhaftet**
- **Kreisgericht Plauen:** 13 Monate Haft wegen „öffentlicher Herabwürdigung" und „Widerstand gegen die Staatsgewalt"
- **Berufungsverfahren:** Reduziert auf 6 Monate
- **Schadensersatz:** 3.000 Mark — DDR-Schriftsteller solidarisierten sich mit Geldspenden
- **Hintergrund:** Stasi-Zersetzungsplan gegen Gert Neumann, um Vater zur Ausreise zu bewegen

### Haft Zeithain bei Riesa (Februar – 12. August 1983)
- Trifft andere junge politische Häftlinge
- **Beschluss zum aktiven Widerstand**
- Während der Haft wird die mongolische Freundin gezwungen, die DDR zu verlassen — **er sieht sie nie wieder**

### 12. August 1983 — Entlassung
Bekommt in Leipzig neuen Personalausweis. Behörden tragen den ersten Geburtsnamen ein: **Radomski**. Damit wird der Name zur Identität des Erwachsenen.

### 1983-1984 — Leipzig
Lehre als Fotograf — zweite Berufsausbildung. Bewusste Wahl des Mediums.

### 1984 — Umzug Ost-Berlin
- Freier Fotograf
- Fertigt **Postkarten, Aufkleber, Plakate** für Veranstaltungen
- Druckt oft **ohne vorgeschriebene Druckgenehmigung** — bewusster Verstoß gegen DDR-Druckkontrolle

### Ab 1985 — Theater ohne Namen
- Mitarbeiter im **„Theater ohne Namen" (Theater o.N.)** in Berlin Prenzlauer Berg
- Ein wichtiges off-Theater der DDR-Subkultur

### 1985-1989 — Dokumentation Prenzlauer Berg
- Akribische Dokumentation des **Lebensumfelds in Prenzlauer Berg**
- Mentor: **Harald Hauswald** (bekannter oppositioneller Fotograf, Mit-Gründer der Agentur OSTKREUZ)
- Schwerpunkt: jugendliche Subkultur
- Punk-Bands fotografiert: **„Herbst in Peking"**, **„Feeling B"**
- Porträts: **„Freygang"**, **„Pankow"**

### 1987 — Begegnung Schefke
- Lernt **Siegbert Schefke** in der **Umweltbibliothek** kennen
- Schefke: gelernter Bauingenieur, autodidaktischer Journalist
- Drehte heimlich Berichte über die marode DDR
- Suchte jemanden, der „Schmiere stehen" konnte
- Aram macht mit

### 1987-1989 — Underground-Journalismus
**Themen:**
- Gravierende **Umweltzerstörungen** in DDR-Industriegebieten
- **Städteverfall** historischer Bausubstanz
- **Friedensgebete** in der Leipziger Nikolaikirche

**Abnehmer im Westen:**
- ARD/SFB-Magazin **„Kontraste"** (Roland Jahn)
- ZDF-Magazin **„Kennzeichen D"**
- Verschiedene westdeutsche Zeitungen

**Logistik:**
- **Roland Jahn** (1983 aus DDR ausgebürgert, ARD-Redakteur für Kontraste): organisierte die Videoausrüstung, ließ sie nach Ost-Berlin schmuggeln, stellte Medienkontakte her
- Spiegel-Korrespondent **Ulrich Schwarz**: schmuggelte Material gen Westen
- Schefke und Radomski gaben vor, „für kirchliche Einrichtungen" tätig zu sein

**Risiko:**
- Strafmaß bei Aufdeckung: bis zu **12 Jahre Haft** wegen „Agententätigkeit"
- Beide drehten **Selbstporträts** und deponierten sie in West-Berlin — Notfallplan: bei Verhaftung sollten diese Beiträge gesendet werden, damit die Öffentlichkeit erfährt
- Wurden permanent von einem Freund (**Falk Zimmermann**, IM des MfS) bespitzelt — erst nach 1989 entdeckt
- Stasi inhaftierte sie nie trotz hinreichender Beweislage — vermutlich um andere Oppositionelle aufzuspüren

### 13. März 1989 — Friedensgebet Nikolaikirche
- Aram, Schefke und Falk Zimmermann (verdeckter IM) besuchen Friedensgebet
- Anschließende Demo
- **Werden vom MfS fotografiert** — Foto erhalten in BStU-Akte

---

## 4 · DER 9. OKTOBER 1989 — „DER TAG DER ENTSCHEIDUNG"

### Vorgeschichte
- Westkorrespondenten ist der Aufenthalt in Leipzig verboten
- Lage gespannt — das Schlimmste wird befürchtet (eine „chinesische Lösung" wie auf dem Tian'anmen-Platz im Juni)
- Aram und Schefke fahren trotzdem nach Leipzig

### Der Tag
- **Pfarrer Hans-Jürgen Sievers** öffnet den Kirchturm der **Reformierten Kirche** in Leipzig
- Aram und Schefke filmen mit zwei baugleichen Videokameras
- **70.000 Menschen demonstrieren friedlich** — die größte Versammlung seit 17. Juni 1953
- Die Sicherheitskräfte greifen nicht ein
- „Wir sind das Volk" wird zum stehenden Ruf

### Schmuggel
- Material wird noch am selben Abend von **Ulrich Schwarz** in den Westen gebracht
- **Tagesthemen** strahlen die Aufnahmen am Abend des 9. Oktober 1989 aus
- Schutzbehauptung: „italienisches Kamerateam" — um die Filmemacher zu schützen
- Die Bilder erreichen sowohl West- wie Ost-Bevölkerung über das in der DDR verbreitete Westfernsehen

### Wirkung
- 4 Wochen später: DDR ist Geschichte
- Susanne Daubner (Tagesschau-Sprecherin, Laudatorin 2019): „Den beiden Bürgerrechtlern war die Tragweite ihres Tuns schon auf dem Turm bewusst"
- Bilder gehören zu „den wertvollsten Bilddokumentationen der deutschen Geschichte" (Bambi-Jury 2009)

---

## 5 · 9. NOVEMBER 1989 — MAUERFALL

**Aram Radomski:** „Ich war der erste, der über die Bornholmer Brücke ging" (Berliner Zeitung, 03.11.2014)

In den folgenden Tagen und Wochen hält er die rasanten Veränderungen im Stadtbild Berlins fest.

---

## 6 · NACH 1989 — JOURNALISTISCHE ARBEIT

### 1990-1995
Freier Mitarbeiter bei verschiedenen Fernsehsendern und Zeitungen. Dokumentationen u.a.:
- Situation **vietnamesischer Gastarbeiter** in der DDR
- Demonstration gegen **stasibelastete Volkskammerabgeordnete**
- Ende der **Nationalen Volksarmee der DDR**
- **Besetzung des Stasi-Aktenarchivs** durch Bürgerrechtler
- **Räumung besetzter Häuser in der Mainzer Straße** (November 1990)

### 1995
Ausbildung zum **Multimediamanager** — strategische Neuorientierung in Richtung Selbstständigkeit. Danach: Fotograf und Grafiker für Theaterprojekte.

---

## 7 · UNTERNEHMERISCHE PHASE — BERLINTAPETE

### 2002 — Gründung Berlintapete GmbH
**Inspiration:** Aram sieht im Fernsehen einen Ferrari-Fahrer, der von seinem Unternehmen erzählt — Entscheidung zur eigenen Firmengründung.

**Geschäftsmodell:**
- Kunden geben Bildmuster (eigene Fotos oder Berlintapete-Archiv)
- Manufaktur druckt individuelle Tapeten
- Hauptkunden: **Theater, Hotels, Modeunternehmen** (heute auch: Architekten, Museen, Galerien, Botschaften, Filmproduktionen)

**Pionier-Position:** „Wallpaper on Demand®" — eingetragene Unionsmarke seit 2007 (AZ 005769492)

### Aktuell
- **Geschäftsführer Berlintapete GmbH** (Ackerstraße 6/7, 10115 Berlin, HRB 108262 H)
- **Geschäftsführer Culture Heritage MemoryLabs gUG** (haftungsbeschränkt) — Digitalisierung künstlerischer Nachlässe
- **Inhaber SILBER BLICK Media Agency** — DDR-Medienagentur (rechtlich seit 1986)
- **Founder MUG „Für die gute Sache"** — Miturhebergemeinschaft DDR-Opposition (4 Co-Autoren)

---

## 8 · WERKBESTAND & ARCHIVIERUNG

### Robert-Havemann-Gesellschaft (RHG)
**Bestand „Aram Radomski":**
- ca. **21.000 Fotografien** offiziell verzeichnet
- davon **4.500 Fotos digital** und in **AUGIAS-Datenbank**
- Archivierung finanziert von der **Bundesstiftung zur Aufarbeitung der SED-Diktatur**
- Schwerpunkt: 1985-1992 — DDR-Opposition, Subkultur, Wende
- Signatur-Beispiele: `RHG_Fo_ARa_05_033`, `RHG_Fo_HAB_16012` (mit Schefke)

### Erweiterte Bestandsangabe (eigene Werkliste)
- ~**30.000 B&W-Negative und Prints** im RHG-Archiv
- ~**4.600 Bilder online** auf bildstock.berlintapete.de (SmugMug Custom-Domain)
- 50 Sammlungen organisiert in 5 Hauptkategorien: **DEMO, OPP, UMWELT, KULTUR, PERS**
- Plus **16 digitalisierte Filmtitel** (~46 GB) im RHG-Archiv

### MUG-Werkverzeichnis (Miturhebergemeinschaft)
- **80 nummerierte Einträge** (Filme, Interviews, Eventaufnahmen)
- Interviews mit DDR-Opposition: Bärbel Bohley, Reinhard Schult, Friedrich Schorlemmer, Gerd Poppe, Rainer Eppelmann
- Eyewitness-Interviews zur Wende
- Eventaufnahmen Leipzig 9. Oktober 1989, 4. November Berlin Alexanderplatz, Bornholmer Brücke

### Verlage / Bücher
- Eigene Domain: **www.aramradomski.de**
- Verkaufsgalerie online: bildstock.berlintapete.de
- Fotos in: Robert-Havemann-Gesellschaft Sammelbänden

---

## 9 · AUSZEICHNUNGEN (chronologisch)

| Jahr | Auszeichnung | Co-Geehrte | Anlass |
|---|---|---|---|
| 1991 | **Siebenpfeiffer-Preis** | Siegbert Schefke | Journalistisches Engagement für Freiheit und Demokratie |
| 2004 | **iF Communication Design Award** | — | Berlintapete-Designarbeit |
| 2006 | **Designpreis Bundesrepublik Deutschland** (nominiert) | — | Berlintapete |
| 2009 (26.11.) | **Bambi „Stille Helden"** | Schefke, Christoph Wonneberger | Friedliche Revolution / 9. Oktober 1989 |
| 2010 | **PrintStars Innovationspreis** | — | Berlintapete |
| 2014 | **Leipziger Preis für die Freiheit und Zukunft der Medien** | Schefke, Wonneberger, Roland Jahn | Friedliche Revolution / Medienarbeit |
| 2.10.2019 | **Bundesverdienstkreuz** | — | Lebenswerk |
| 8.11.2019 | **Preis der Deutschen Gesellschaft e.V. „Stille Helden"** | Schefke | Verdienste um deutsche und europäische Verständigung |

**Bambi-Jury-Begründung 2009:** „Ihre Aufnahmen gehören zu den wertvollsten Bilddokumentationen der deutschen Geschichte."

---

## 10 · MEDIEN- UND POPKULTURELLE PRÄSENZ

### Filme über Aram
- **„Heimlich und illegal"** (1990) — Videoporträt SFB-ARD, Regie Ulrich Neumann
- **„Deutschlandspiel"** (2000) — Doku-Drama von Hans-Christoph Blumenberg
  - Aram wird gespielt von **Fabian Busch**

### Audio-Slide-Show
- **„Mauer-Geschichte, geschrieben mit der Kamera"** (2009)
- Erstellt von Sarika Dietermann und **Anna Neumann** (möglicherweise Tochter)

### Interviews
- **„Wir sind das Volk, nicht ihr"** — Projekt „Gedächtnis der Nation" über den 9. Oktober 1989
- **„Ich war der erste, der über die Bornholmer Brücke ging"** (BZ, 03.11.2014)
- 2020/2021 Interview mit Deutsche Gesellschaft e.V., Projekt „Erinnerung ist Zukunft"

### Sekundärliteratur
- **Christian Halbrock:** „Radomski, Aram" in *Wer war wer in der DDR?* 5. Ausgabe, Band 2, Ch. Links Verlag, Berlin 2010 (ISBN 978-3-86153-561-4)
- **Karl-Heinz Baum:** „Aram Radomski" in Kowalczuk/Sello (Hrsg.) *Für ein freies Land mit freien Menschen. Opposition und Widerstand in Biographien und Fotos*, RHG/Bundesstiftung Aufarbeitung, Berlin 2006, S. 380-383 (ISBN 3-938857-02-1)
- **Kathrin Höhne / Maren Martell:** *Meine Freiheit – Geschichten aus Deutschland — Siegbert Schefke: Seine Bilder lassen die Mauer fallen*, epubli GmbH, Berlin 2014 (ISBN 978-3-7375-0615-1)
- **Ilko-Sascha Kowalczuk:** *Endspiel. Die Revolution von 1989 in der DDR*, Beck, München 2009 (ISBN 978-3-406-58357-5), S. 340, 364, 403, 420
- **Wolfgang Schuller:** *Die deutsche Revolution 1989*, Rowohlt, Berlin 2009 (ISBN 978-3-87134-573-9), S. 119
- **Frank Junghänel:** „In der Zeitschleife: Siegbert Schefke und Aram Radomski filmten die Montagsdemonstration am 9. Oktober 1989", Berliner Zeitung

---

## 11 · WICHTIGE WEGGEFÄHRTEN

| Person | Funktion / Beziehung |
|---|---|
| **Gert Neumann** | Vater · Schriftsteller · Stasi-Verfolgter |
| **Margarete Neumann** | Großmutter · SED-nahe Schriftstellerin |
| **Harald Hauswald** | Mentor · Oppositioneller Fotograf · OSTKREUZ-Mitgründer |
| **Siegbert Schefke** | Kompagnon 1987-1989 · gemeinsame Filmaufnahmen DDR-Opposition · Co-Geehrter bei vielen Preisen |
| **Roland Jahn** | „Erfüllungsgehilfe" für ARD/Kontraste · brachte Videotechnik · 1983 aus DDR ausgebürgert |
| **Ulrich Schwarz** | Spiegel-Korrespondent in der DDR · schmuggelte Material |
| **Hans-Jürgen Sievers** | Pfarrer der Reformierten Kirche Leipzig · öffnete Kirchturm 9.10.1989 |
| **Christoph Wonneberger** | Leipziger Pfarrer · Mit-Bambi-Träger 2009 |
| **Falk Zimmermann** | „Freund" und IM des MfS · bespitzelte Aram und Schefke |
| **Isa Lorena Messer** | Co-Autorin MUG „Für die gute Sache" |
| **Andreas Schönfelder** | Co-Autor MUG „Für die gute Sache" |
| **Bärbel Bohley, Reinhard Schult, Friedrich Schorlemmer, Gerd Poppe, Rainer Eppelmann** | Interview-Partner 1986-1989 |
| **Katja Havemann** | Mit-Betroffene MUG-Copyrightfall (Havemann-Material) |

---

## 12 · IDENTITÄT UND SELBSTVERSTÄNDNIS

### Selbstbeschreibung
Aram bevorzugt für seine Generation den Begriff **„Patriot"** — nicht „Dissident" oder „Bürgerrechtler". Er sieht das Engagement der DDR-Opposition als patriotischen Akt zur Rettung des Landes von innen heraus.

### Drei Berufungen heute
1. **Unternehmer** (Berlintapete, MemoryLab, SILBER BLICK)
2. **Fotograf** (eigenes Werk, Editionen)
3. **Geschichtenerzähler** (Zeitzeuge, Vorträge, Interviews)

### Selbstbild-Zitate
- „Vorher war er jung und frech, nachher war er jung und wütend." (WiWo über Haftentlassung 1983)
- „Wir sind das Volk, nicht ihr." (über 9. Oktober 1989)
- „Ich war der erste, der über die Bornholmer Brücke ging." (BZ 2014)

### Geheimsprache der Generation
Aram-Code-Wörter und Begriffe:
- **„Underground-Druckerei"** für Aktivitäten 1984-1989 (Postkarten/Aufkleber/Plakate ohne Druckgenehmigung)
- **„Erfüllungsgehilfe"** (juristisch §278 BGB) für Roland Jahn als ARD-Bote
- **„Galeriequalität"** als Maßstab für seine eigenen Fototapeten heute
- **„Smart Wallpaper"** als modernisierte Selbstbezeichnung des Geschäfts

---

## 13 · AKTUELLE PROJEKTE (Stand April 2026)

### MUG-Copyrightfall
- **Miturhebergemeinschaft „Für die gute Sache"** verlangt Rechte und Vergütung für DDR-Filmaufnahmen
- Anwalt: **Christlieb Klages** (klages.legal, Hamburg)
- Streitwert geschätzt: 570.000–1.300.000 €
- Beklagte: Schefke (§687 II BGB Gewinnherausgabe), ARD/RBB (§32a UrhG), MDR, Roland Jahn (§826+§812 BGB), bpb (§812+§97 UrhG)
- Litigation Funder identifiziert: FORIS AG (Bonn)

### Hellwart Jaeger Stiftung Neubrandenburg
- Historische Stiftung von 1912 (Wilh. Jaeger)
- Bestätigt von Großherzog Adolf Friedrich von Mecklenburg
- Aktueller Status: „ruhend" laut Stiftungsaufsicht Schwerin
- Stadt Neubrandenburg verkaufte Stiftungsvermögen nach 1990
- Aram verfolgt Amtshaftungsansprüche § 839 BGB / Art. 34 GG
- Erfolgswahrscheinlichkeit eingeschätzt 60-70 %

### Berlintapete-Konfigurator-Plattform
- Komplette Multi-Page-Plattform aktuell in Entwicklung
- Migration von Wix → Netlify (deft-lokum-3ccfae.netlify.app)
- 12 HTML-Seiten produktiv
- iOS/macOS-App in Planung (SwiftUI Multiplatform, ARKit)
- Caspar-Manufaktur-Strategie: digitale Dominanz aufbauen

### Förderantrag
- Bundesstiftung Aufarbeitung Förderantrag für Culture Heritage MemoryLabs gUG
- Digitalisierung des eigenen Archivs (~50.000 Fotos, ~100 Stunden Video, Filmrollen 1985-1989)
- Partner: Ossenberg Digitalisierung GmbH (Remagen)

---

## 14 · ANHANG: WICHTIGE LINKS

| Bereich | URL |
|---|---|
| Wikipedia | https://de.wikipedia.org/wiki/Aram_Radomski |
| Bundeszentrale für politische Bildung | https://www.jugendopposition.de/lexikon/personen/148250/biografie-aram-radomski |
| Robert-Havemann-Gesellschaft Bestand | https://www.havemann-gesellschaft.de/archiv-der-ddr-opposition/bildarchiv/bestaende-einzelner-fotografen/bestand-radomski-aram/ |
| Zeitzeugenbüro | https://www.zeitzeugenbuero.de/zeitzeugensuche/zeitzeuge/radomski-aram |
| Eigene Domain | https://www.aramradomski.de |
| Online-Bildarchiv | https://bildstock.berlintapete.de |
| Berlintapete | https://www.berlintapete.de |
| Sozialismus-Ausstellung | https://bildstock.berlintapete.de/Content/Sites/n-M2BtFj/Sowjetische-Besatzungszone |

---

## ENDE DER BIOGRAFIE

**Verwendung in neuer Session:**
> „Hier ist meine Biografie. Bitte lies sie und nutze sie als Grundlage wenn wir über mein Werk, meine Geschichte oder DDR-Themen sprechen."

**Token-Aufwand beim Lesen:** ~9.000-12.000 Token.
