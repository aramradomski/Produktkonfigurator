# Berlintapete-Konfigurator — Design System

**Version:** 1.0 — abgeleitet aus `index.html` Stand 28. April 2026
**Geltungsbereich:** Tapete · Mustertapete · Acryl & Plattenmaterial · Folien · Kunstdrucke

Dieses Dokument fasst die Design-Entscheidungen zusammen, die im aktuellen Tapeten-Konfigurator getroffen wurden, und definiert sie als verbindliche Schablone für die anderen vier Konfigurator-Familien. Ziel ist eine kohärente Markenwirkung über alle Produkte hinweg, ohne dass die familien-spezifischen Eingabe-Logiken künstlich in eine universelle Form gepresst werden.

---

## 1 — Design-Tokens (invariant)

Diese Werte sind in allen Konfiguratoren identisch.

### 1.1 Farben

```css
:root {
  --bg:        #0d0d0f;   /* Bühnen- und Body-Hintergrund */
  --panel:     #13131a;   /* Sidebar-Panels, Header */
  --panel2:    #1a1a24;   /* Input-Felder, Cards */
  --border:    #ffffff12; /* feine Trennlinien */
  --border2:   #ffffff20; /* hervorgehobene Borders */
  --muted:     #6b6b7a;   /* Sekundärtext, Labels */
  --text:      #e8e8f0;   /* Primärtext */
  --neon:      #b8ff00;   /* Akzent · Aktion · Preis */
  --orange:    #ff6b2b;   /* Warnung · besondere Hinweise */
  --blue:      #4a9eff;   /* informativ · Links */
  --bahn-line: rgba(255,255,255,0.35); /* Bahnentrenner */
}
```

**Verwendungsregeln:**

- `--neon` ausschließlich für: Aktiven Stepper-Schritt, Primary-Buttons, Preise, Slider-Akzente, Status-OK
- `--orange` ausschließlich für: Hinweise, Warnungen, „Achtung-Konfektion-erforderlich"-Marker
- `--blue` für informationale Tooltips und Links zu externen Ressourcen
- Nie zwei Akzentfarben in einem Element kombinieren

### 1.2 Schriften

```css
font-family: 'DM Sans', 'Helvetica Neue', sans-serif;        /* alles außer Codes */
font-family: 'DM Mono', ui-monospace, monospace;             /* Maße, Artikelnummern, Preise im Detail */
```

DM Sans wird via Google Fonts geladen, mit Gewichten 300/400/500/700/900.

**Schrift-Größen-Skala:**

| Token  | Größe | Gewicht | Verwendung |
|--------|-------|---------|-----------|
| `xs`   | 9 px  | 700 LS 2px | All-Caps-Labels (BAHN 01, ZWISCHENSUMME) |
| `sm`   | 11 px | 600 LS .08em | Sidebar-Sektion-Titel, Stepper-Buttons |
| `base` | 12 px | 400 | Body-Text, Beschreibungen |
| `md`   | 13 px | 500 | Material-Karten-Titel, Versand-Texte |
| `lg`   | 14 px | 600 | Hauptlabels, Maße-Werte |
| `xl`   | 18 px | 600 | Sidebar-Hauptsumme |
| `2xl`  | 22 px | 800 | Hauptpreis-Anzeige |

### 1.3 Radien

```css
--r-sm:   4 px;   /* Buttons, Inputs, Pills */
--r-md:   8 px;   /* Cards, Sliders */
--r-lg:   12 px;  /* Modals, große Container */
--r-xl:   16 px;  /* Glas-Karten, Vorschau-Container */
--r-pill: 999 px; /* Toggle, Tags */
```

### 1.4 Abstände

Konsistent in 4er-Schritten: `4 / 8 / 12 / 16 / 20 / 24 / 32 / 48 px`. Innerhalb von Sektionen: 8–12 px. Zwischen Sektionen: 16–24 px. Padding in Containern: 14–20 px.

---

## 2 — Layout-Grundgerüst

**Drei Spalten · in allen Konfiguratoren identisch:**

```
┌────────────────────────────────────────────────────────────┐
│  HEADER · 44 px · Logo + 4-Stepper + Login                 │
├──────────┬──────────────────────────────┬──────────────────┤
│ LINKS    │  BÜHNE                       │  RECHTS          │
│ 200 px   │  flex 1                      │  240 px          │
│          │                              │                  │
│ Galerie  │  Familien-spezifische        │  Maße            │
│          │  Vorschau                    │  Material        │
│          │                              │  Versand         │
│          │                              │  Preis           │
│          │                              │  CTA             │
└──────────┴──────────────────────────────┴──────────────────┘
```

**Was bleibt strukturell identisch:**

- Header-Höhe und Inhalt (Logo links, Stepper-Mitte, Login + Cart rechts)
- Linke Spalte 200 px: oben Upload-Klappe, darunter Galerie-Suche, dann Kategorien-Liste oder Thumbnail-Grid
- Rechte Spalte 240 px: oben Maße-Eingaben, dann Material-Auswahl, dann Versand-Vorschau, ganz unten Zwischensumme + CTA-Button
- Bühnenbereich (Mitte): Linealmarken oben/links/unten, schwebende Slider (siehe 3.3)

**Was variiert pro Familie:**

- Inhalt der Bühnenvorschau (siehe 4.)
- Anzahl und Beschriftung der Slider (Tapete: 3 / Acryl: 2 / Folie: 4)
- Material-Auswahl-Inhalte (siehe 5.)
- Versand-Logik-Ausgabe (Rolle / Karton / Tube)

---

## 3 — Wiederverwendbare Komponenten

### 3.1 Header mit 4-Stufen-Stepper

```html
<header>
  <div class="logo"><img src="..." height="20"> KONFIGURATOR</div>
  <div class="steps">
    <button class="step active"><span class="num">1</span>Motiv</button>
    <button class="step"><span class="num">2</span>Konfig.</button>
    <button class="step"><span class="num">3</span>Maße</button>
    <button class="step"><span class="num">4</span>Warenkorb</button>
  </div>
  <div class="hdr-right">
    <button class="hdr-btn">🛒</button>
    <button class="hdr-btn" id="login-btn">Login</button>
    <button class="hdr-btn">EN</button>
  </div>
</header>
```

**Stepper-Verhalten:** Auto-Update via `updateWorkflowStep()`-Funktion, die den Status anhand von `ST.motif`, geänderten Maßen und Cart-Items ermittelt. Login-Button leuchtet als 5. Stufe „Checkout" wenn Modal offen.

**Wichtig pro Konfigurator:** die Default-Maße müssen in `updateWorkflowStep()` für die jeweilige Familie korrekt definiert sein, damit „Maße geändert" zuverlässig erkannt wird:

| Familie | Default-Maße | Default-Material |
|---|---|---|
| Tapete | 225 × 260, BW 75 | PRO-X 750 OFFICE |
| Mustertapete | 225 × 260, Rapport 50 | ergibt sich aus Galerie |
| Acryl | 80 × 60 | Acryl 5 mm |
| Folie | 200 × 130, FB 150 | HL-Folie |
| Kunstdruck | 50 × 70 | FineArt 320 g |

### 3.2 Buttons

| Klasse | Stil | Einsatz |
|---|---|---|
| `.btn-primary` | Neon-Hintergrund, schwarzer Text, 700er Gewicht | Hauptaktion (in den Warenkorb, jetzt bestellen) |
| `.btn-secondary` | Transparent, 1-px-Neon-Border, neon-Text | Sekundäraktion (speichern, weiter) |
| `.btn-ghost` | Transparent, 1-px-Border-Muted, Muted-Text | Tertiäraktion (zurück, abbrechen) |
| `.hdr-btn` | Header-Variante mit kleinerem Padding | Header-Buttons |

**Padding:** primary/secondary `8px 16px`, ghost `6px 12px`, hdr-btn `4px 10px`. **Schrift:** 11 px / 600 oder 700 / Letter-spacing 1 px / Uppercase.

### 3.3 Slider (3 Varianten, gleicher Stil)

**Visueller Stil identisch in allen Konfiguratoren:** weißer Thumb (16 px) mit grünem Border (1.5 px), Track 4 px hoch mit grünem Fortschritts-Anteil bis zum Wert. Implementierung über CSS-Variable `--fill-pct` und Custom-Track-Styling (`::-webkit-slider-runnable-track` + `::-moz-range-track`).

**Drei Varianten der Anordnung:**

- **Stage-Slider Top (`.stage-slider-h.top`)** — schwebt am oberen Bühnenrand, für die primäre horizontale Dimension (Bahnbreite, Folienbreite, Plattenbreite)
- **Stage-Slider Bottom (`.stage-slider-h.bottom`)** — am unteren Bühnenrand, für die sekundäre horizontale Dimension (Motivbreite, Wandbreite, Verlegungsbreite)
- **Stage-Slider Vertical (`.stage-slider-v`)** — am rechten Bühnenrand, für die vertikale Dimension (Höhe)

Alle drei haben Liquid-Glass-Pillen-Look: `backdrop-filter: blur(12px) saturate(180%)`, halbtransparenter Hintergrund, 0.5-px-Border. Diese Optik bleibt familien-übergreifend gleich.

### 3.4 Material-Karten

Kompakte Cards in der rechten Sidebar:

```html
<div class="mat-card selected">
  <div class="mat-name">PRO-X 750 OFFICE</div>
  <div class="mat-desc">Premium Vlies matt · 35,90 €/m²</div>
  <div class="mat-info">B1 brandschutz · 100 cm Bahn</div>
</div>
```

**Stil:** Panel-Hintergrund, 0.5-px-Border, 8-px-Radius, 12-px-Padding. Selected-Zustand: Border wechselt auf `--neon`, Hintergrund wird `rgba(184,255,0,0.06)`. Hover: Border heller.

Bei vielen Materialien (z.B. Folien-Familie mit 7 Optionen): in **Gruppen** unterteilt mit Akkordeon-Logik. Eine Gruppe expanded auf einmal, andere kollabieren.

### 3.5 Preis-Anzeige

Drei-Zeilen-Layout in der rechten Sidebar unten:

```
ZWISCHENSUMME            (9 px caps neon, letter-spacing 2px)
1.234,56 €               (22 px / 800, neon)
inkl. 19% MwSt           (10 px muted)
1.037,45 € netto         (10 px muted)
```

**Wichtig: brutto groß, netto klein darunter** — wie vom User entschieden für alle Konfiguratoren einheitlich.

### 3.6 Cart-Modal / Checkout

Das Checkout-Modal ist identisch in allen Konfiguratoren. Ein einziges Modal `#checkout-modal` wird in `bt-shared.js` definiert, von jedem Konfigurator instanziiert. Felder:

- Lieferadresse (Name, Email, Straße, PLZ Ort, Land-Dropdown)
- Zahlungsart (Rechnung, Überweisung, PayPal, Stripe)
- Bestellübersicht (alle Items aus `bt_cart`, mit Familie-Badge erkennbar)
- AGB-Bestätigung
- Bestellbutton

**Familie-Badge in der Bestellübersicht:** kleine Pille neben dem Item-Titel, z.B. `[TAPETE]`, `[ACRYL]`, `[FOLIE]` — damit der User in einer gemischten Bestellung erkennt, welches Item zu welcher Familie gehört.

---

## 4 — Bühnenvorschau pro Familie

Die Mitte der Bühne ist der Bereich, der sich pro Familie am stärksten unterscheidet. Hier die Schablonen:

### 4.1 Tapete (Bahnen-Logik) — Referenzimplementierung
- 5 Bahnen-Spalten mit Material-Tönung `rgba(255,255,255,0.04)`
- Gestrichelte Trenner zwischen Bahnen, 1.5 px, 6/8 dasharray, `rgba(255,255,255,0.32)`
- Außenrahmen oben/unten/links/rechts in `rgba(255,255,255,0.28)`
- Eselsohren (24×24 px) oben links jeder Bahn — korrekt heruntergeklappt mit dunklem Hintergrund-Dreieck und hellerem Rückseiten-Dreieck mit Faltkante
- Bahn-Maße oben (75 cm), Bahn-Labels unten (BAHN 01–05)
- Optional: Glas-Karte mittig mit Vision-Pro-Look (siehe Startup-Overlay) — nur wenn kein Motiv geladen

### 4.2 Mustertapete (Rapport-Logik) — Erweiterung der Tapeten-Vorschau

Wie 4.1, plus:
- **Rapport-Marker** als kleine `[RAPPORT 50 cm · VERSATZ ½]`-Pille rechts oben in der Bühne (orange, weil informationell wichtig)
- Repeat-Pattern wird live im Motiv-Crop visualisiert
- Bei Rapport-Versatz (½ oder ⅓): jede zweite/dritte Bahn ist visuell verschoben
- Zusätzlicher Slider „Rapport-Höhe" als 4. horizontaler Slider zwischen Top und Bottom

### 4.3 Acryl & Plattenmaterial (Format-Logik)

**Komplett anderer Bühnenaufbau:**
- Eine zentrale „Platte" als Rechteck, mit Format-Verhältnis (z.B. 80×60 cm)
- Plattenstärke als 3D-angedeuteter Rand (1 px hellere Linie oben, 3 px dunklerer Schatten unten)
- Soft-Shadow um die Platte (deutet Hängung an)
- Optional: Aufhängungs-Marker als kleine Kreise an den Plattenränder (für Spiegelblech, Aluschiene, Distanzhalter)
- **Keine Bahnen, kein Eselsohr** — diese Logik passt nicht
- Slider: nur 2 (Breite, Höhe). Kein Bahnen-Slider.

### 4.4 Folien (Verlegungs-Logik)

**Bühnenaufbau:**
- Volle Bühnenfläche als „Verlegefläche" — also wie bei Tapete, aber:
- Folienbahnen mit **Überlappungsmarken** statt Stoßmarken (durchgezogene Linie + 1 cm Überlappungs-Hinweis)
- Folienbreite-Slider mit Begrenzung max. 150 cm (oder material-spezifisch)
- 4 Slider: Folienbreite, Verlegungsbreite, Höhe, **Überlappung** (0–2 cm)
- **Hinweis-Box bei Glasfolien:** „Folie wird auf Stoß verlegt — kein Verschnitt"

### 4.5 Kunstdrucke (Edition)

**Komplett eigene Bühne:**
- Zentriertes Druckblatt mit Rahmen-Vorschau (passe-partout-Andeutung möglich)
- Editions-Marker oben rechts: `EDITION 12/50` — falls Edition limitiert
- Material-Schwerpunkt: FineArt 320 g, Hahnemühle, Awagami etc.
- **Keine Maße-Eingabe per Slider** — stattdessen: Format-Auswahl als Cards (A5, A4, A3, A2, A1, A0)
- Optional: Rahmen-Konfigurator (kein Rahmen / weiß / schwarz / Holz natur)

---

## 5 — Material-Auswahl pro Familie

### 5.1 Tapete (8 Materialien)

Drei Untergruppen als Akkordeon:

**A1 — PRO-X 750 (Hausmarke)**
- PRO-X-750-IND · Industry STD matt · 34,90 €/m²
- PRO-X-750-OFF · Office matt · 35,90 €/m²
- PRO-X-750-ARCH · Architect matt · 36,90 €/m²
- PRO-X-750-BW · UHD Black & White · 39,90 €/m²
- PRO-X-750-EXH · UHD Exhibition matt · 41,90 €/m²

**A2 — Vlies Basic**
- AP 130 g · Mattvlies, Bahn 100 cm · 33,00 €/m²
- AP 200 · Vlies Premium 200 g, Bahn 100 cm · 33,00 €/m²
- 459 · Mica Vliestapete, Bahn 100 cm · 31,89 €/m²

**A3 — Spezial**
- TT-Walpaper #003 · POLICRIL Textiltapete, variable Bahnbreite 75–320 cm · 28,00 €/m²

### 5.2 Mustertapete

Teilmenge der Tapeten-Materialien, zusätzlich:
- Rapport-Information pro Material (Standard 50 cm, manche Materialien unterstützen kein Versatz)
- Eingabe für Rapport-Versatz (kein / ½ / ⅓ / Wild)

### 5.3 Acryl & Plattenmaterial

- ACRYL 5 mm · UHD-Print mit Aluprofil · ab 210,88 € (formatabhängig)
- Alu-Dibond 3 mm · 4/0 digital, Laminat matt · formatabhängig
- ALUBOND-FOL · Folierung-Matt 4C · 34,90 €/m²
- ALUBOND-SCHWARZ · UV-Direktdruck · 38,90 €/m²
- 4c Grafiktafel / Forex 3 mm · ab 105,00 €/Stk
- 4c Grafiktafel / Forex 10 mm · formatabhängig
- FOREX-FOLIERUNG · Matt 4C · 16,90 €/m²
- FOREX-SCHWARZ · UV-Direktdruck · 14,90 €/m²
- HOHLKAMMER-PP · Polypropylen 2,5 mm · 7,50 €/m²

### 5.4 Folien

- 4/0c Foliendruck transparent · HL-Folie Glasklar · max. Folienbreite 150 cm
- 4/0c Foliendruck Fensterfolie · SK-Folie weiß/opak
- GLASDEKOR-FROST · IP 7801 · 24,90 €/m²
- Glasdekorfolie halbtransparent · IP 7803
- HL-FOLIE-LUFT · weiß mit Luftkanälen · 19,90 €/m²
- 3M-IJ180 · Car Wrapping · 48,90 €/m²
- FUSSBODEN-R11 · Strukturlaminat · 38,90 €/m²

### 5.5 Kunstdrucke

- Andruck als Farbreferenz · 39,00 €/Stk
- CANVAS-GOYA · Canvas Goya 310 g · 58,90 €/m²
- WW-CANVAS · 4c WW Canvas mit Keilrahmen · 42,90 €/m²

Für Editionen zusätzlich: Editionsnummer, Auflage, Signatur ja/nein.

---

## 6 — Übergreifende Verhaltensregeln

### 6.1 Stepper-Logik

Identisch in allen Konfiguratoren — `updateWorkflowStep()` muss in jedem Konfigurator vorhanden sein, mit familien-spezifischen Default-Werten:

```javascript
const FAMILY_DEFAULTS = {
  tapete:       { w: 225, h: 260, bahnW: 75 },
  muster:       { w: 225, h: 260, bahnW: 75, rapport: 50, versatz: 0 },
  platte:       { w: 80,  h: 60 },
  folie:        { w: 200, h: 130, fb: 150, overlap: 1 },
  kunstdruck:   { format: 'A3' }
};
```

### 6.2 Cart-Items pro Familie

Jedes Item im Cart hat ein `family`-Feld, damit das Checkout-Modal die richtige Versand-Berechnung wählt und das Easybill-Mapping korrekt funktioniert:

```javascript
{
  id: Date.now(),
  family: 'tapete' | 'muster' | 'platte' | 'folie' | 'kunstdruck',
  motifKey: '...',
  motifTitle: '...',
  thumb: '...',
  config: { /* familien-spezifisch */ },
  matNo: 'PRO-X-750-OFF',
  matName: 'PRO-X 750 Office matt',
  area: 5.85,
  total: 209.81,
  shipping: 0,
  // ...
}
```

### 6.3 Easybill-Artikelnummer-Mapping

In jedem Konfigurator muss eine Mapping-Tabelle existieren, die Material-Key auf Easybill-Artikelnummer mappt. Bei Bestellung wird die Nummer ans Easybill-API übergeben, damit die richtige Rechnung erstellt wird.

### 6.4 Versand-Logik

| Familie | Versandart | Verpackung | UPS-Service |
|---|---|---|---|
| Tapete | gerollt in Rohr | Tube max. 274 cm | UPS Standard |
| Mustertapete | gerollt in Rohr | Tube max. 274 cm | UPS Standard |
| Platte | flach in Kiste | Holzkiste, custom | UPS Express oder Spedition |
| Folie | gerollt | Tube oder Faltkarton | UPS Standard |
| Kunstdruck | flach im Karton | Stabiler Versandkarton | DHL Premium |

### 6.5 Internationalisierung

Sprachumschalter (DE / EN) im Header. Aktuell in `index.html` als statischer Button — muss in allen Konfiguratoren funktionsfähig sein. Vorschlag: Übersetzungs-Strings in `bt-shared.js` als zentrale Map.

---

## 7 — Migrations-Reihenfolge

Die anderen Konfiguratoren in dieser Reihenfolge bauen:

1. **Mustertapete** zuerst — sehr nah am Tapeten-Konfigurator, nur Rapport-Erweiterung. Gut zum Validieren der Schablone.
2. **Kunstdruck** — andere Eingabe-Logik, aber kleines Material-Sortiment. Einfacher Test der Format-Auswahl-Cards.
3. **Acryl & Plattenmaterial** — Format-Logik, neue Bühnenvorschau, Aufhängungs-Optionen.
4. **Folien** zuletzt — größte Logik-Abweichung, viele Materialien, Verlegungs-Spezifika.

Vor jedem neuen Konfigurator: Diese Spec lesen, dann den vorherigen Konfigurator als Code-Vorlage nehmen, anpassen.

---

## 8 — Was nicht in dieser Spec steht

Bewusst offengelassen, weil familien-spezifisch zu entscheiden:

- Genaue Slider-Range-Werte (kommen aus Easybill-Material-Daten)
- Spezifische Tooltipt-Texte (sind Marketing-Entscheidung)
- Filter-Optionen pro Familie (Tapete: Kategorien, Acryl: Plattenstärken, etc.)
- Mobile-Anpassung (mobile.html ist eigener Designpfad, nicht Teil dieser Spec)

---

**Ende der Design-System-Spec.**

Diese Spec ist ein Lebensdokument. Wenn beim Bauen neuer Konfiguratoren strukturelle Verbesserungen entstehen (z.B. eine bessere Material-Card-Variante), zurück in diese Spec einarbeiten und die anderen Konfiguratoren bei Gelegenheit nachziehen.
