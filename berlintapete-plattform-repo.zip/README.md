# Berlintapete Plattform

Single-file-HTML-Konfiguratoren der Berlintapete GmbH (Wallpaper on Demand), gehostet auf Netlify.

## Seiten
| Datei | Zweck |
|---|---|
| `index.html` | Startseite / Einstieg |
| `tapete.html` | Tapeten-Konfigurator (SmugMug-Motive, Canon Colorado Materialien, Preis) — **wird neu aufgebaut** |
| `muster.html` | Mustertapete |
| `platte.html` | Acryl & Plattenmaterial |
| `edition.html`, `originals.html` | Kunstdrucke / Editionen |
| `upload.html` | Eigenes Motiv hochladen |
| `produkt.html`, `showcase.html`, `mobile.html`, `appletv.html` | Produkt- und Präsentationsseiten |
| `netlify/functions/easybill-proxy.js` | Rechnungserstellung via Easybill (Key nur in Env-Vars) |

Design-Vorgaben: `berlintapete-design-system-spec.md`.

## Deploy
Netlify → *Add new site → Import from Git* → dieses Repo. `netlify.toml` und `_redirects` (SmugMug-Proxy) werden automatisch erkannt.
Env-Variablen nach `.env.example` in Netlify eintragen — nie im Frontend.

## Lokal
```
npm i -g netlify-cli
netlify dev
```
